(function(){

  var app = angular.module('unacademic.users', [
    'templates'
  ]);

})();
