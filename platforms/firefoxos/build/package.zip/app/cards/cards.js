(function(){
  var app = angular.module('unacademic.cards', [
    'templates'
  ]);
})();
