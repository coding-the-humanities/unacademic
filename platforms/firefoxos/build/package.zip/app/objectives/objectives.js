(function(){

  var app = angular.module('unacademic.objectives', [
    'templates',
    'unacademic.tasks'
  ]);

})();
