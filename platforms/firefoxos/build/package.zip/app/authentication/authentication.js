(function(){

  var app = angular.module('unacademic.authentication', [
  ]);

})();
