"use strict";
"use strict";
"use strict";
"use strict";
(function() {
  var app = angular.module('unacademic');
  app.service('Objective', function() {
    return Objective;
    function Objective() {}
  });
})();
